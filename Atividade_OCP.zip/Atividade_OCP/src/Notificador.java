public class Notificador {

    private CanalNotificacao canal;

    public Notificador(CanalNotificacao canal) {
        this.canal = canal;
    }

    public void enviar(String mensagem) {
        canal.enviar(mensagem);
    }

}


//public class Notificador {
//    public void enviar(String tipo, String mensagem) {
//        if (tipo.equals("EMAIL")) {
//            System.out.println("Enviando e-mail: " + mensagem);
//        } else if (tipo.equals("SMS")) {
//            System.out.println("Enviando SMS: " + mensagem);
//        } else if (tipo.equals("PUSH")) {
//            System.out.println("Enviando push notification: " + mensagem);
//        }
//    }
//}
//1. Identifique as violações do OCP.
//2. Crie uma interface CanalNotificacao.
//3. Implemente classes para EmailNotificacao, SmsNotificacao e PushNotificacao.
//4. Faça a classe Notificador utilizar polimorfismo para enviar mensagens.