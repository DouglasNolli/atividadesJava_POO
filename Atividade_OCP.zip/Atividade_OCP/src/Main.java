public class Main {
    public static void main(String[] args) {
        Notificador notificadorEmail = new Notificador(new EmailNotificacao());
        notificadorEmail.enviar("Bem-vindo ao sistema!");

        Notificador notificadorSms = new Notificador(new SmsNotificacao());
        notificadorSms.enviar("Seu código é 1234.");

        Notificador notificadorPush = new Notificador(new PushNotificacao());
        notificadorPush.enviar("Você tem uma nova mensagem!");
    }
}
