public class PushNotificacao implements CanalNotificacao{

    @Override
    public void enviar(String mensagem) {
        System.out.println("Enviando push notification: " + mensagem);
    }
}
