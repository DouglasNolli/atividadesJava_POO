public interface CanalNotificacao {
    void enviar(String mensagem);
}
