package PrincipioDaSegregacaoDeInterface.Exercicio2.Interface;

public interface RecursoRenovar extends RecursosBiblioteca{
    void renovar();
}
