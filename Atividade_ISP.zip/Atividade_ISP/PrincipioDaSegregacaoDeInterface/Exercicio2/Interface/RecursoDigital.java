package PrincipioDaSegregacaoDeInterface.Exercicio2.Interface;

public interface RecursoDigital extends RecursosBiblioteca {
    void baixarArquivoDigital();
}
