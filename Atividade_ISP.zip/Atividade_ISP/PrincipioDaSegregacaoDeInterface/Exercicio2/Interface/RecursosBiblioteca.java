package PrincipioDaSegregacaoDeInterface.Exercicio2.Interface;

public interface RecursosBiblioteca {
    void consultarDisponibilidade();
    void reservar();
}
