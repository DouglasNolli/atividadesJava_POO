package PrincipioDaSegregacaoDeInterface.Exercicio2.Interface;

public interface RecursImprimir extends RecursosBiblioteca {
    void imprimirCopia();
}
