package PrincipioDaSegregacaoDeInterface.Exercicio2.Interface;

public interface RecursoDevolver extends RecursosBiblioteca{
    void devolver();
}
