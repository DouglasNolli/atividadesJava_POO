package PrincipioDaSegregacaoDeInterface.Exercicio2.Interface;

public interface RecursoEmprestar extends RecursosBiblioteca {
    void emprestar();
}
