package PrincipioDaSegregacaoDeInterface.Exercicio2.Interface;

public interface RecursoMidia extends RecursosBiblioteca {
    void reproduzirMidia();
}
