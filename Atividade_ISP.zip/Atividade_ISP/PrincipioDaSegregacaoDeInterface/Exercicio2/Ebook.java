package PrincipioDaSegregacaoDeInterface.Exercicio2;

import PrincipioDaSegregacaoDeInterface.Exercicio2.Interface.RecursoDigital;

public class Ebook implements RecursoDigital {
    @Override
    public void consultarDisponibilidade(){
        System.out.println("Ebook disponivel");
    }

    @Override
    public void reservar(){
        System.out.println("Ebook reservado");
    }

    @Override
    public void baixarArquivoDigital(){
        System.out.println("Ebook baixando...");
    }
}
