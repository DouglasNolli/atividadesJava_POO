package PrincipioDaSegregacaoDeInterface.Exercicio2;

import PrincipioDaSegregacaoDeInterface.Exercicio2.Interface.RecursoMidia;
import PrincipioDaSegregacaoDeInterface.Exercicio2.Interface.RecursosBiblioteca;

public class DVD implements RecursosBiblioteca, RecursoMidia {
    @Override
    public void consultarDisponibilidade(){
        System.out.println("DVD disponivel");
    }

    @Override
    public void reservar(){
        System.out.println("DVD reservado");
    }

    @Override
    public void reproduzirMidia(){
        System.out.println("Reproduzindo midia");
    }
}
