package PrincipioDaSegregacaoDeInterface.Exercicio2;

import PrincipioDaSegregacaoDeInterface.Exercicio2.Interface.RecursoEmprestar;

public class Livro implements RecursoEmprestar {
    @Override
    public void consultarDisponibilidade(){
        System.out.println("Livro disponivel");
    }

    @Override
    public void reservar(){
        System.out.println("Livro reservado");
    }

    @Override
    public void emprestar(){
        System.out.println("Livro emprestado");
    }

}
