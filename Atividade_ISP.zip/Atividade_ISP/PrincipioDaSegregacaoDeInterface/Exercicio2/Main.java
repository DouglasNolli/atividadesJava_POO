package PrincipioDaSegregacaoDeInterface.Exercicio2;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Ebook ebook = new Ebook();
        Livro livro = new Livro();
        DVD dvd = new DVD();

        ebook.consultarDisponibilidade();
        ebook.reservar();
        ebook.baixarArquivoDigital();

        livro.consultarDisponibilidade();
        livro.reservar();
        livro.emprestar();

        dvd.consultarDisponibilidade();
        dvd.reservar();
        dvd.reproduzirMidia();
    }
}
