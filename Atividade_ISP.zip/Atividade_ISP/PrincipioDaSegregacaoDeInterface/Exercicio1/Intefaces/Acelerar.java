package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface Acelerar {
    void acelerar();
}
