package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface Estacionar {
    void estacionar();
}
