package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface Frear {
    void frear();
}
