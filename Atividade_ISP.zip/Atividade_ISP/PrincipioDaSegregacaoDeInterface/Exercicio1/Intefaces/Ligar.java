package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface Ligar {
    void ligar();
}
