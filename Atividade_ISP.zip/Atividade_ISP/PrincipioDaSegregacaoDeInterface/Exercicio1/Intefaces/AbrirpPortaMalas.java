package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface AbrirpPortaMalas {
    void abrirPortaMalas();
}
