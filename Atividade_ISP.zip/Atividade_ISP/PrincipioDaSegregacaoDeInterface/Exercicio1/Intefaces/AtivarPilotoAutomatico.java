package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface AtivarPilotoAutomatico {
    void ativarPilotoAutomatico();
}
