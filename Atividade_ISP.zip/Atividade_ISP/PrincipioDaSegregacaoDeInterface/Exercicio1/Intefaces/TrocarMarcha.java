package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface TrocarMarcha {
    void trocarMarcha();
}
