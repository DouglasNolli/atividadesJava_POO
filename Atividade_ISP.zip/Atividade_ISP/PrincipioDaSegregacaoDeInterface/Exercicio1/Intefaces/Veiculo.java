package PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces;

public interface Veiculo {
    void veiculo();
}
