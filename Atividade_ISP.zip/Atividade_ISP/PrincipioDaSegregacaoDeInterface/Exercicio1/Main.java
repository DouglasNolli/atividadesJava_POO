package PrincipioDaSegregacaoDeInterface.Exercicio1;

public class Main {
    public static void main(String[] args) {
        Bicicleta bicicleta = new Bicicleta();

        bicicleta.veiculo();
        bicicleta.frear();
    }
}
