package PrincipioDaSegregacaoDeInterface.Exercicio1;

import PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces.Frear;
import PrincipioDaSegregacaoDeInterface.Exercicio1.Intefaces.Veiculo;

public class Bicicleta implements Veiculo, Frear {
    @Override
    public void veiculo(){
        System.out.println("Veiculo do tipo bicicleta");
    }
    @Override
    public void frear(){
        System.out.println("Bicicleta freiando...");
    }
}
