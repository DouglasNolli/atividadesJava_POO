package PrincipioDaSubstituicao.atividade3;

public class PgtoDinheiro implements MetodoPagamento{
    @Override
    public void enviarNotificacao(){
    }

    @Override
    public void realizarPagamento(){
        System.out.println("Pagamento realizado por dinheiro\n");
    }
}
