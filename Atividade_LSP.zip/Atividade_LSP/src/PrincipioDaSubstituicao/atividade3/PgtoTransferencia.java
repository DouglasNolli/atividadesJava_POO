package PrincipioDaSubstituicao.atividade3;

public class PgtoTransferencia implements MetodoPagamento{
    @Override
    public void enviarNotificacao(){
        System.out.println("Notificação enviada");
    }

    @Override
    public void realizarPagamento(){
        System.out.println("Pagamento realizado por tranferencia\n");
    }
}
