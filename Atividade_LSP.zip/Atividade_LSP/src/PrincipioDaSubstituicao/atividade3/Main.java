package PrincipioDaSubstituicao.atividade3;

public class Main {
    public static void main(String[] args) {
        PgtoCatao pgtoCatao = new PgtoCatao();
        PgtoDinheiro pgtoDinheiro = new PgtoDinheiro();
        TranferenciaDOC tranferenciaDOC = new TranferenciaDOC();
        TransferenciaTED transferenciaTED = new TransferenciaTED();

        pgtoCatao.enviarNotificacao();
        pgtoCatao.realizarPagamento();

        pgtoDinheiro.enviarNotificacao();
        pgtoDinheiro.realizarPagamento();

        tranferenciaDOC.enviarNotificacao();
        tranferenciaDOC.realizarPagamento();

        transferenciaTED.enviarNotificacao();
        transferenciaTED.realizarPagamento();

    }
}
