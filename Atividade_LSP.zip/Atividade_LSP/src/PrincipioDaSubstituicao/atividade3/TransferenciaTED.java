package PrincipioDaSubstituicao.atividade3;

public class TransferenciaTED extends PgtoTransferencia{
    @Override
    public void enviarNotificacao(){
        System.out.println("Voce realizou a tranferencia no dia xx/xx/xxxx");
    }

    @Override
    public void realizarPagamento(){
        System.out.println("Pagamento realizado por tranferencia TED\n");
    }
}
