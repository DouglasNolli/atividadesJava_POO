package PrincipioDaSubstituicao.atividade3;

public interface MetodoPagamento {
    void enviarNotificacao();
    void realizarPagamento();
}
