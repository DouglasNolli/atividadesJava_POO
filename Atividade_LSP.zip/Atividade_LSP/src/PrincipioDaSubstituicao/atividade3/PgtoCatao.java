package PrincipioDaSubstituicao.atividade3;

public class PgtoCatao implements MetodoPagamento{
    @Override
    public void enviarNotificacao(){
        System.out.println("Seu cartão foi utilizado para uma compra no dia xx/xx/xxxx");
    }
    @Override
    public void realizarPagamento(){
        System.out.println("Pagamento realizado via cartão\n");
    }
}
