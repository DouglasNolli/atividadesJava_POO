package PrincipioDaSubstituicao.atividade1_2;

public class Pinguim extends AveQueNaoVoa {
    @Override
    public void emitirSom(){
        System.out.println("emitindo som de pinguim");
    }
    @Override
    public void comer(){
        System.out.println("comendo peixes");
    }
}
