package PrincipioDaSubstituicao.atividade1_2;

public class AveQueNaoVoa implements Aves {
    @Override
    public void emitirSom(){
        System.out.println("som generico");
    }
    @Override
    public void comer(){
        System.out.println("comendo alpiste");
    }
}
