package PrincipioDaSubstituicao.atividade1_2;

public class AveQueVoa implements Aves {
    @Override
    public void emitirSom(){
        System.out.println("Emitindo som generico");
    }
    @Override
    public void comer(){
        System.out.println("comendo alpiste");
    }
}
