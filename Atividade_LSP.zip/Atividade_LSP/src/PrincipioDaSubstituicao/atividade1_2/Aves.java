package PrincipioDaSubstituicao.atividade1_2;

public interface Aves {
    void emitirSom();
    void comer();
}
