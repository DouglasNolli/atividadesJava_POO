package exercicio_1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Boletim {

    private String nomeAluno;
    private List<Double> notas = new ArrayList<>();

    public Boletim(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public String getNomeAluno() {
        return nomeAluno;
    }

    public List<Double> getNotas() {
        return notas;
    }

    public void adicionarNota(double nota) {
        notas.add(nota);
    }
}

public class SituacaoAluno {

    public double calcularMedia(Boletim boletim) {
        return boletim.getNotas().stream()
                .mapToDouble(Double::doubleValue)
                .average()
                .orElse(0);
    }

    public String gerarSituacao(Boletim boletim) {
        double media = calcularMedia(boletim);
        return media >= 7 ? "Aprovado" : "Reprovado";
    }
}

public class RegistroBoletim {

    import java.io.FileWriter;
    import java.io.IOException;

    public void salvarEmArquivo(Boletim boletim, double media) throws IOException {
        try (FileWriter writer = new FileWriter(boletim.getNomeAluno() + "_boletim.txt")) {
            writer.write("Aluno: " + boletim.getNomeAluno() + "\nMédia: " + media + "\n");
        }
    }

    public void enviarEmail(String email) {
        System.out.println("Enviando boletim para " + email);
    }
}

/*
    Liste as múltiplas responsabilidades da classe.
    A classe possui as seguintes funções:
        1º - Adiciona notas ao boletim
        2º - Calcula a média
        3º - Preve a situação do aluno: Aprovado/Reprovado
        4º - Salva todos os arquivos
        5º - Encaminha o boletim para usuario
*/

/*
Explique como a refatoração melhora a manutenção e o reuso.

    Agora refatorando cada classe tem sua função, onde boletim e o registro de notas e do aluno,
    situacaoAluno é onde verifica se ele foi aprovado ou reprovado,
    e registroBoletim é para registrar o boletim do aluno e encaminhar o resultado por e-mail;
*/