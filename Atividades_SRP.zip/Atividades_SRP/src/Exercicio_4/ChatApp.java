package Exercicio_4;

public class ChatApp {
    public void enviarMensagem(String texto) { ... }
    public void exibirHistorico() { ... }
    public void salvarMensagemNoBanco(String texto) { ... }
    public void notificarContato(String contato) { ... }
}

/*
Quais são as responsabilidades que deveriam ser separadas?
    Todas as reponsabilidades deveriam ser separadas
*/

/*
Crie uma proposta de diagrama textual (ou classes Java simples) demonstrando a refatoração.

--------------------------
|   ChatApp              |
--------------------------
| - EnvioMensagemService |
| - HistoricoService     |
| - MensagemRepository   |
| - NotificacaoService   |
--------------------------
| + enviarMensagem(texto)|
--------------------------

--------------------------
| EnvioMensagemService   |
--------------------------
| + enviar(texto)        |
--------------------------

--------------------------
| HistoricoService       |
--------------------------
| + exibirHistorico()    |
--------------------------

--------------------------
| MensagemRepository     |
--------------------------
| + salvarMensagem(texto)|
--------------------------

--------------------------
| NotificacaoService     |
--------------------------
| + notificar(contato)   |
--------------------------
*/

/*
Qual seria a vantagem para o time de QA (testes) após essa refatoração?

Basicamente depois de fazer a fatoração, é possivel testar cada classe separadamente,
então se acaso tiver algum problema será possivel testar separadamente,ou seja, isolar
o problema e assim descobrindo e consertando erros futuros mais rapido.
*/