package exercicio_2;

import java.time.LocalTime;

public class RelogioService {
    private RelogioDigital relogioDigital;
    private SalvarHoraEmArquivo salvarHoraEmArquivo;
    private TocarAlarme tocarAlarme;

    public RelogioService() {
        this.relogioDigital = new RelogioDigital();
        this.salvarHoraEmArquivo = new SalvarHoraEmArquivo();
        this.tocarAlarme = new TocarAlarme();
    }

    public void executarOperacoes() {
        LocalTime hora = relogioDigital.mostrarHora();

        System.out.println("Hora atual: " + hora);
        salvarHoraEmArquivo.salvarHoraEmArquivo(hora);
        tocarAlarme.tocarAlarme();
    }
}

