package exercicio_2;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;

public class SalvarHoraEmArquivo {

    public void salvarHoraEmArquivo(LocalTime hora) {
        try (FileWriter f = new FileWriter("hora.txt")) {
            f.write(LocalTime.now().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
