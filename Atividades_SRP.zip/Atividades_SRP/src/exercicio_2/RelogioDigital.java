package exercicio_2;

import java.time.LocalTime;

public class RelogioDigital {

    public LocalTime mostrarHora() {
        LocalTime horaAtual = LocalTime.now();
        System.out.println("Hora atual: " + horaAtual);
        return horaAtual;
    }
}

/*
Identifique as violações do SRP.

    O sistema está fazendo tres coisas em uma unica classe, mostrando o horario, salvando e tocando o alarme,
    isso violas os principios da SRP pois deveria cada função ter sua classe especifica a fim de não amarrar
    o codigo por um todo.
*/
/*
Escreva um RelogioService que orquestre as operações.
*/