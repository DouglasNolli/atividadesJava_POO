package exercicio_2;

public class TocarAlarme {

    public void tocarAlarme() {
        System.out.println("BEEP! Alarme tocando!");
    }

}
