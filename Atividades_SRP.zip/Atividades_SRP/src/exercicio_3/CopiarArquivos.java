package exercicio_3;

public class CopiarArquivos {
    public void copiar(String origem, String destino) {
        System.out.println("Copiando arquivos de " + origem + " para " + destino);
        // lógica real de cópia
    }
}
