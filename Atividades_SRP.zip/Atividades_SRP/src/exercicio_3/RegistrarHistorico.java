package exercicio_3;

public class RegistrarHistorico {
    public void registrar(String mensagem) {
        System.out.println("LOG: " + mensagem);
    }
}
