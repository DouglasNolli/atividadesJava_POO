package exercicio_3;

public class BackupAutomatizado {

/*
Liste todas as responsabilidades.
    1º copia os arquivos
    2º compacta os arquivos
    3º envia email para notificação
    4º registra o historico de operações


Explique como o SRP contribui para reutilizar partes desse sistema em outros contextos.
Agora refatorando cada classe tem sua função especifica, então caso haja algum defeito
em algo especifico fica mais facil de localizar onde está o possivel erro e corrigindo, além de que
a estrutura fica mais organizada e visual
*/

}

