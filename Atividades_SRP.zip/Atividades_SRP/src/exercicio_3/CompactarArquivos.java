package exercicio_3;

public class CompactarArquivos {
    public void compactar(String destinoZip) {
        System.out.println("Compactando arquivos para " + destinoZip);
        // lógica real de compactação
    }
}
