package exercicio_3;

public class Notificacao {
    public void enviar(String destinatario, String mensagem) {
        System.out.println("Enviando e-mail para " + destinatario + ": " + mensagem);
    }
}
