package exercicio_5;

public class ContaBancaria {

    private double saldo;

    public void depositar(double valor) {
        saldo += valor;
    }

    public void sacar(double valor) {
        saldo -= valor;
    }

    public double getSaldo() {
        return saldo;
    }
}

/*
Identifique e nomeie as responsabilidades distintas.

1º depositar
2º sacar
3º gerarExtrato
4º salvarNoBanco
5º enviarEmail

Explique como isso facilita mudanças no envio de notificações sem afetar o resto do sistema.
    Com a refatoração agora é possivel editar so o e-mail sem afetar as outras classes, ou seja, toda e
    qualquer manutenção fica mais rapida e simplificada
*/