package exercicio_5;

public class SalvarNoBanco {
    public void salvarNoBanco() {
        System.out.println("Salvando conta no banco de dados...");
    }
}
