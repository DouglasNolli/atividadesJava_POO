package exercicio_5;

public class GerarExtrato {
    public void gerarExtrato(ContaBancaria conta) {
        System.out.println("Saldo atual: " + conta.getSaldo());
    }
}
