package exercicio_5;

public class EnviarEmail {
    public void enviarEmail(String email) {
        System.out.println("Enviando notificação para " + email);
    }
}
