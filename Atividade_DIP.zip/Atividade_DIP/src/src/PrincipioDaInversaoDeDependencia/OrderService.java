package PrincipioDaInversaoDeDependencia;

public class OrderService {
    private Database database;

    public OrderService(Database database) {
        this.database = database;
    }

    public void createOrder(Order order) {
        database.save(order);
    }

    public Order getOrder(int id) {
        return database.findById(id);
    }
}
