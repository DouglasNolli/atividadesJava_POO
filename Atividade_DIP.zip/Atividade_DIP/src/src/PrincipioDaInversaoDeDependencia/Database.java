package PrincipioDaInversaoDeDependencia;

public interface Database {
    void save(Order order);
    Order findById(int id);
}
