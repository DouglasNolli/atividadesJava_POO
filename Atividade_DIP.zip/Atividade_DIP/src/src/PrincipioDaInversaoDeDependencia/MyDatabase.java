package PrincipioDaInversaoDeDependencia;

public class MyDatabase implements Database{
    @Override
    public void save(Order order) {
        // Salva no MySQL
    }

    @Override
    public Order findById(int id) {
        // Busca no MySQL
        return null;
    }
}
