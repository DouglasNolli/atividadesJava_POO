package PrincipioDaInversaoDeDependencia;

public class ma {
//    public class OrderService {
//        private MySQLDatabase database = new MySQLDatabase();
//
//        public void createOrder(Order order) {
//            database.save(order);
//        }
//
//        public Order getOrder(int id) {
//            return database.findById(id);
//        }
//    }
//
//    public class MySQLDatabase {
//        public void save(Order order) {
//            // Salva no MySQL
//        }
//
//        public Order findById(int id) {
//            // Busca no MySQL
//            return null;
//        }
//    }
}
